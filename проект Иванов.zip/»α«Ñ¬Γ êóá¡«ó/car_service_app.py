import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from database import CarServiceDB


class ThemedCarServiceApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🚗 Автомастерская 'ВИТЯЗЬ' 🛠️")
        self.root.geometry("800x600")
        self.root.configure(bg='#2C3E50')

        # Инициализация базы данных
        self.db = CarServiceDB()

        # Цветовая схема в стиле автомастерской
        self.colors = {
            'primary': '#E74C3C',  # Красный - цвет стоп-сигналов
            'secondary': '#3498DB',  # Синий - цвет рабочих комбинезонов
            'accent': '#F39C12',  # Оранжевый - цвет предупреждений
            'dark_bg': '#2C3E50',  # Темно-синий фон
            'light_bg': '#ECF0F1',  # Светло-серый фон
            'success': '#27AE60',  # Зеленый - успех
            'text_light': '#FFFFFF',  # Белый текст
            'text_dark': '#2C3E50'  # Темный текст
        }

        # Переменные для статуса
        self.status_var = tk.StringVar(value="Готов к работе")

        # Настройка стилей
        self.setup_styles()
        self.setup_ui()

    def setup_styles(self):
        style = ttk.Style()

        # Современная тема
        style.theme_use('clam')

        # Настраиваем стили для разных элементов
        style.configure('TNotebook', background=self.colors['dark_bg'])
        style.configure('TNotebook.Tab',
                        background=self.colors['dark_bg'],
                        foreground=self.colors['text_light'],
                        padding=[20, 5])
        style.map('TNotebook.Tab',
                  background=[('selected', self.colors['primary'])],
                  foreground=[('selected', self.colors['text_light'])])

        # Стиль для кнопок
        style.configure('Accent.TButton',
                        background=self.colors['primary'],
                        foreground=self.colors['text_light'],
                        focuscolor='none',
                        font=('Arial', 10, 'bold'))
        style.map('Accent.TButton',
                  background=[('active', self.colors['accent']),
                              ('pressed', self.colors['accent'])])

        # Стиль для большой кнопки
        style.configure('Big.TButton',
                        background=self.colors['primary'],
                        foreground=self.colors['text_light'],
                        focuscolor='none',
                        font=('Arial', 14, 'bold'),
                        padding=(30, 20))
        style.map('Big.TButton',
                  background=[('active', self.colors['accent']),
                              ('pressed', self.colors['accent'])])

        # Стиль для фреймов
        style.configure('Card.TFrame', background=self.colors['light_bg'])
        style.configure('Dark.TFrame', background=self.colors['dark_bg'])

        # Стиль для меток
        style.configure('Title.TLabel',
                        background=self.colors['dark_bg'],
                        foreground=self.colors['text_light'],
                        font=('Arial', 16, 'bold'))

        style.configure('Heading.TLabel',
                        background=self.colors['light_bg'],
                        foreground=self.colors['primary'],
                        font=('Arial', 12, 'bold'))

        style.configure('Normal.TLabel',
                        background=self.colors['light_bg'],
                        foreground=self.colors['text_dark'],
                        font=('Arial', 10))

    def setup_ui(self):
        # Заголовок приложения
        header_frame = ttk.Frame(self.root, style='Dark.TFrame')
        header_frame.pack(fill='x', padx=10, pady=10)

        title_label = ttk.Label(header_frame,
                                text="🚗 АВТОМАСТЕРСКАЯ 'ВИТЯЗЬ' 🛠️",
                                style='Title.TLabel')
        title_label.pack(pady=10)

        subtitle_label = ttk.Label(header_frame,
                                   text="Профессиональный ремонт и обслуживание автомобилей",
                                   style='Normal.TLabel',
                                   background=self.colors['dark_bg'],
                                   foreground=self.colors['text_light'])
        subtitle_label.pack(pady=(0, 10))

        # Создаем вкладки
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill='both', expand=True, padx=10, pady=10)

        # Вкладка записи на обслуживание
        self.booking_frame = ttk.Frame(self.notebook, style='Card.TFrame')
        self.notebook.add(self.booking_frame, text="📝 Запись на обслуживание")
        self.setup_booking_tab()

        # Вкладка просмотра записей
        self.records_frame = ttk.Frame(self.notebook, style='Card.TFrame')
        self.notebook.add(self.records_frame, text="📋 Мои записи")
        self.setup_records_tab()

        # Статус бар
        status_bar = ttk.Label(self.root, textvariable=self.status_var,
                               relief='sunken', style='Normal.TLabel',
                               background=self.colors['dark_bg'],
                               foreground=self.colors['text_light'])
        status_bar.pack(fill='x', side='bottom', ipady=5)

    def setup_booking_tab(self):
        # Основной контейнер
        main_container = ttk.Frame(self.booking_frame, style='Card.TFrame')
        main_container.pack(fill='both', expand=True, padx=20, pady=20)

        # Заголовок формы
        form_header = ttk.Label(main_container,
                                text="Заполните форму для записи",
                                style='Heading.TLabel')
        form_header.pack(pady=(0, 20))

        # Фрейм для формы с карточным дизайном
        form_card = ttk.Frame(main_container, style='Card.TFrame', relief='raised', borderwidth=1)
        form_card.pack(fill='both', expand=True, padx=10, pady=10)

        # Сетка для формы
        form_grid = ttk.Frame(form_card, style='Card.TFrame')
        form_grid.pack(fill='both', expand=True, padx=30, pady=30)

        # ФИО
        name_label = ttk.Label(form_grid, text="ФИО*:", style='Normal.TLabel')
        name_label.grid(row=0, column=0, sticky='w', pady=12)
        self.name_var = tk.StringVar()
        self.name_entry = ttk.Entry(form_grid, textvariable=self.name_var, width=30, font=('Arial', 10))
        self.name_entry.grid(row=0, column=1, sticky='ew', pady=12, padx=(20, 0))

        # Марка авто
        brand_label = ttk.Label(form_grid, text="Марка авто*:", style='Normal.TLabel')
        brand_label.grid(row=1, column=0, sticky='w', pady=12)
        self.brand_var = tk.StringVar()
        self.brand_entry = ttk.Entry(form_grid, textvariable=self.brand_var, width=30, font=('Arial', 10))
        self.brand_entry.grid(row=1, column=1, sticky='ew', pady=12, padx=(20, 0))

        # Модель авто
        model_label = ttk.Label(form_grid, text="Модель авто*:", style='Normal.TLabel')
        model_label.grid(row=2, column=0, sticky='w', pady=12)
        self.model_var = tk.StringVar()
        self.model_entry = ttk.Entry(form_grid, textvariable=self.model_var, width=30, font=('Arial', 10))
        self.model_entry.grid(row=2, column=1, sticky='ew', pady=12, padx=(20, 0))

        # Вид обслуживания
        service_label = ttk.Label(form_grid, text="Вид обслуживания:", style='Normal.TLabel')
        service_label.grid(row=3, column=0, sticky='w', pady=12)
        self.service_var = tk.StringVar()
        self.service_combo = ttk.Combobox(form_grid, textvariable=self.service_var, width=27, font=('Arial', 10))
        self.service_combo['values'] = (
            "🛢️ Регламентное ТО",
            "⚙️ Замена масла",
            "🔍 Диагностика",
            "🚘 Ремонт ходовой",
            "🌀 Шиномонтаж",
            "🛑 Замена тормозов",
            "🔨 Кузовной ремонт",
            "⚡ Электрика",
            "🧼 Мойка и чистка",
            "🔧 Разное"
        )
        self.service_combo.current(0)
        self.service_combo.grid(row=3, column=1, sticky='ew', pady=12, padx=(20, 0))

        # Дата
        date_label = ttk.Label(form_grid, text="Дата*:", style='Normal.TLabel')
        date_label.grid(row=4, column=0, sticky='w', pady=12)
        self.date_var = tk.StringVar()
        self.date_entry = ttk.Entry(form_grid, textvariable=self.date_var, width=30, font=('Arial', 10))
        self.date_entry.insert(0, datetime.now().strftime("%d.%m.%Y"))
        self.date_entry.grid(row=4, column=1, sticky='ew', pady=12, padx=(20, 0))

        # Время
        time_label = ttk.Label(form_grid, text="Время*:", style='Normal.TLabel')
        time_label.grid(row=5, column=0, sticky='w', pady=12)
        self.time_var = tk.StringVar()
        self.time_entry = ttk.Entry(form_grid, textvariable=self.time_var, width=30, font=('Arial', 10))
        self.time_entry.insert(0, datetime.now().strftime("%H:%M"))
        self.time_entry.grid(row=5, column=1, sticky='ew', pady=12, padx=(20, 0))

        # Подсказки
        tip_frame = ttk.Frame(form_grid, style='Card.TFrame')
        tip_frame.grid(row=6, column=0, columnspan=2, pady=20)

        tip1 = ttk.Label(tip_frame, text="* - обязательные поля",
                         style='Normal.TLabel', foreground='gray')
        tip1.pack()
        tip2 = ttk.Label(tip_frame, text="Формат даты: ДД.ММ.ГГГГ",
                         style='Normal.TLabel', foreground='gray')
        tip2.pack()
        tip3 = ttk.Label(tip_frame, text="Формат времени: ЧЧ:ММ",
                         style='Normal.TLabel', foreground='gray')
        tip3.pack()

        # Настройка веса колонок для выравнивания
        form_grid.columnconfigure(1, weight=1)

        # Выделенная кнопка прямо под формой
        button_container = ttk.Frame(main_container, style='Card.TFrame')
        button_container.pack(fill='x', padx=20, pady=(20, 10))

        # Большая заметная кнопка
        self.submit_btn = ttk.Button(button_container,
                                     text="🚗 ЗАПИСАТЬСЯ НА ОБСЛУЖИВАНИЕ 🚗",
                                     command=self.submit_booking,
                                     style='Big.TButton')
        self.submit_btn.pack(fill='x', ipady=15)

        # Добавляем дополнительный акцент под кнопкой
        accent_frame = ttk.Frame(button_container, height=5, style='Dark.TFrame')
        accent_frame.pack(fill='x', pady=(5, 0))
        accent_frame.configure(relief='raised', borderwidth=1)

    def setup_records_tab(self):
        main_container = ttk.Frame(self.records_frame, style='Card.TFrame')
        main_container.pack(fill='both', expand=True, padx=20, pady=20)

        # Заголовок
        title_label = ttk.Label(main_container, text="История ваших записей",
                                style='Heading.TLabel')
        title_label.pack(pady=(0, 20))

        # Фрейм для поиска и управления
        search_buttons_frame = ttk.Frame(main_container, style='Card.TFrame')
        search_buttons_frame.pack(fill='x', pady=10)

        # Поиск
        search_frame = ttk.Frame(search_buttons_frame, style='Card.TFrame')
        search_frame.pack(side='left', fill='x', expand=True)

        ttk.Label(search_frame, text="Поиск:", style='Normal.TLabel').pack(side='left')
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=20)
        self.search_entry.pack(side='left', padx=(10, 5))
        self.search_entry.bind('<KeyRelease>', self.on_search)

        # Кнопки управления
        buttons_frame = ttk.Frame(search_buttons_frame, style='Card.TFrame')
        buttons_frame.pack(side='right')

        self.update_btn = ttk.Button(buttons_frame, text="🔄 Обновить",
                                     command=self.update_records_list)
        self.update_btn.pack(side='left', padx=(0, 10))

        self.delete_btn = ttk.Button(buttons_frame, text="🗑️ Удалить выбранную",
                                     command=self.delete_record, state='disabled')
        self.delete_btn.pack(side='left')

        # Статистика
        self.stats_var = tk.StringVar(value="Всего записей: 0 | Сегодня: 0")
        stats_label = ttk.Label(main_container, textvariable=self.stats_var,
                                style='Normal.TLabel')
        stats_label.pack(pady=5)

        # Фрейм для таблицы
        table_frame = ttk.Frame(main_container, style='Card.TFrame')
        table_frame.pack(fill='both', expand=True)

        # Создаем Treeview с полосой прокрутки
        columns = ('id', 'date', 'time', 'fio', 'car', 'service')
        self.records_tree = ttk.Treeview(table_frame, columns=columns, show='headings')

        # Настраиваем заголовки
        self.records_tree.heading('id', text='ID')
        self.records_tree.heading('date', text='📅 Дата')
        self.records_tree.heading('time', text='🕒 Время')
        self.records_tree.heading('fio', text='👤 ФИО')
        self.records_tree.heading('car', text='🚙 Автомобиль')
        self.records_tree.heading('service', text='🛠️ Обслуживание')

        # Настраиваем ширину колонок
        self.records_tree.column('id', width=40, anchor='center')
        self.records_tree.column('date', width=90, anchor='center')
        self.records_tree.column('time', width=70, anchor='center')
        self.records_tree.column('fio', width=150)
        self.records_tree.column('car', width=130)
        self.records_tree.column('service', width=180)

        # Скрываем колонку ID
        self.records_tree.column('id', width=0, stretch=False)

        # Полоса прокрутки
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL,
                                  command=self.records_tree.yview)
        self.records_tree.configure(yscroll=scrollbar.set)

        self.records_tree.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')

        # Привязываем событие выбора
        self.records_tree.bind('<<TreeviewSelect>>', self.on_record_select)

        self.update_records_list()

    def submit_booking(self):
        self.status_var.set("Проверка данных...")

        # Проверяем заполнение полей
        if not all([
            self.name_var.get(),
            self.brand_var.get(),
            self.model_var.get(),
            self.date_var.get(),
            self.time_var.get()
        ]):
            messagebox.showwarning("Внимание", "Заполните все обязательные поля!")
            self.status_var.set("Ошибка: заполните все поля")
            return

        # Проверяем формат даты и времени
        try:
            datetime.strptime(self.date_var.get(), "%d.%m.%Y")
            datetime.strptime(self.time_var.get(), "%H:%M")
        except ValueError:
            messagebox.showwarning("Внимание", "Проверьте формат даты (ДД.ММ.ГГГГ) и времени (ЧЧ:ММ)!")
            self.status_var.set("Ошибка: неверный формат даты/времени")
            return

        # Убираем эмодзи из типа услуги для хранения
        service_text = self.service_var.get()
        for emoji in ["🛢️", "⚙️", "🔍", "🚘", "🌀", "🛑", "🔨", "⚡", "🧼", "🔧"]:
            service_text = service_text.replace(emoji, "").strip()

        # Сохраняем в базу данных
        try:
            record_id = self.db.add_record(
                self.name_var.get(),
                self.brand_var.get(),
                self.model_var.get(),
                service_text,
                self.date_var.get(),
                self.time_var.get()
            )

            self.status_var.set("Запись успешно добавлена!")
            messagebox.showinfo("Успех", f"🎉 Вы успешно записаны на обслуживание! ID записи: {record_id}")
            self.clear_form()
            self.update_records_list()

        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось сохранить запись: {str(e)}")
            self.status_var.set("Ошибка при сохранении")

    def clear_form(self):
        self.name_var.set("")
        self.brand_var.set("")
        self.model_var.set("")
        self.service_combo.current(0)
        self.date_var.set(datetime.now().strftime("%d.%m.%Y"))
        self.time_var.set(datetime.now().strftime("%H:%M"))
        self.status_var.set("Форма очищена, готов к новой записи")

    def update_records_list(self, records=None):
        # Очищаем Treeview
        for item in self.records_tree.get_children():
            self.records_tree.delete(item)

        # Получаем записи из базы данных
        if records is None:
            records = self.db.get_all_records()

        # Добавляем записи в Treeview
        for record in records:
            car_info = f"{record['car_brand']} {record['car_model']}"

            # Добавляем иконки в зависимости от типа услуги
            service_icon = "🛠️"
            service_text = record['service'].lower()

            if "то" in service_text:
                service_icon = "🛢️"
            elif "масл" in service_text:
                service_icon = "⚙️"
            elif "диагност" in service_text:
                service_icon = "🔍"
            elif "ходов" in service_text:
                service_icon = "🚘"
            elif "шин" in service_text:
                service_icon = "🌀"
            elif "тормоз" in service_text:
                service_icon = "🛑"
            elif "кузов" in service_text:
                service_icon = "🔨"
            elif "электр" in service_text:
                service_icon = "⚡"
            elif "мойк" in service_text or "чистк" in service_text:
                service_icon = "🧼"

            display_service = f"{service_icon} {record['service']}"

            self.records_tree.insert('', 'end',
                                     values=(
                                         record['id'],
                                         record['date'],
                                         record['time'],
                                         record['fio'],
                                         car_info,
                                         display_service
                                     ))

        # Обновляем статистику
        total_records = len(records)
        today_records = self.db.get_today_records_count()

        self.stats_var.set(f"Всего записей: {total_records} | Сегодня: {today_records}")
        self.status_var.set(f"Список обновлен. Записей: {total_records}")

    def on_record_select(self, event):
        selection = self.records_tree.selection()
        if selection:
            self.delete_btn.config(state='normal')
        else:
            self.delete_btn.config(state='disabled')

    def delete_record(self):
        selection = self.records_tree.selection()
        if not selection:
            return

        if messagebox.askyesno("Подтверждение", "Удалить выбранную запись?"):
            # Получаем ID выбранной записи
            selected_item = selection[0]
            record_id = self.records_tree.item(selected_item, 'values')[0]

            # Удаляем запись из базы данных
            try:
                if self.db.delete_record(record_id):
                    self.update_records_list()
                    self.delete_btn.config(state='disabled')
                    self.status_var.set("Запись удалена")
                else:
                    messagebox.showerror("Ошибка", "Не удалось удалить запись")
            except Exception as e:
                messagebox.showerror("Ошибка", f"Ошибка при удалении: {str(e)}")

    def on_search(self, event):
        """Обработка поиска записей"""
        search_term = self.search_var.get().strip()

        if search_term:
            # Выполняем поиск в базе данных
            records = self.db.search_records(search_term)
            self.update_records_list(records)
            self.status_var.set(f"Найдено записей: {len(records)}")
        else:
            # Показываем все записи
            self.update_records_list()


if __name__ == "__main__":
    root = tk.Tk()
    app = ThemedCarServiceApp(root)
    root.mainloop()