import sqlite3
import os
from datetime import datetime


class CarServiceDB:
    def __init__(self, db_name="car_service.db"):
        self.db_name = db_name
        self.init_database()

    def init_database(self):
        """Инициализация базы данных и создание таблицы если не существует"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS service_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fio TEXT NOT NULL,
                car_brand TEXT NOT NULL,
                car_model TEXT NOT NULL,
                service TEXT NOT NULL,
                date TEXT NOT NULL,
                time TEXT NOT NULL,
                timestamp TEXT NOT NULL
            )
        ''')

        conn.commit()
        conn.close()

    def add_record(self, fio, car_brand, car_model, service, date, time):
        """Добавление новой записи на обслуживание"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()

        timestamp = datetime.now().isoformat()
        cursor.execute('''
            INSERT INTO service_records (fio, car_brand, car_model, service, date, time, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (fio, car_brand, car_model, service, date, time, timestamp))

        conn.commit()
        record_id = cursor.lastrowid
        conn.close()

        return record_id

    def get_all_records(self):
        """Получение всех записей"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()

        cursor.execute('''
            SELECT id, fio, car_brand, car_model, service, date, time, timestamp
            FROM service_records 
            ORDER BY timestamp DESC
        ''')

        records = []
        for row in cursor.fetchall():
            records.append({
                'id': row[0],
                'fio': row[1],
                'car_brand': row[2],
                'car_model': row[3],
                'service': row[4],
                'date': row[5],
                'time': row[6],
                'timestamp': row[7]
            })

        conn.close()
        return records

    def delete_record(self, record_id):
        """Удаление записи по ID"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()

        cursor.execute('DELETE FROM service_records WHERE id = ?', (record_id,))

        conn.commit()
        deleted = cursor.rowcount > 0
        conn.close()

        return deleted

    def get_today_records_count(self):
        """Получение количества записей на сегодня"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()

        today = datetime.now().strftime("%d.%m.%Y")
        cursor.execute('SELECT COUNT(*) FROM service_records WHERE date = ?', (today,))

        count = cursor.fetchone()[0]
        conn.close()

        return count

    def search_records(self, search_term):
        """Поиск записей по ФИО, марке или модели авто"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()

        search_pattern = f'%{search_term}%'
        cursor.execute('''
            SELECT id, fio, car_brand, car_model, service, date, time, timestamp
            FROM service_records 
            WHERE fio LIKE ? OR car_brand LIKE ? OR car_model LIKE ?
            ORDER BY timestamp DESC
        ''', (search_pattern, search_pattern, search_pattern))

        records = []
        for row in cursor.fetchall():
            records.append({
                'id': row[0],
                'fio': row[1],
                'car_brand': row[2],
                'car_model': row[3],
                'service': row[4],
                'date': row[5],
                'time': row[6],
                'timestamp': row[7]
            })

        conn.close()
        return records